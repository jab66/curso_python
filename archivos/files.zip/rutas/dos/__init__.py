def init(db, usuario, **otros):
    print(f"Usuario {usuario} conectado a la base de datos {db}")

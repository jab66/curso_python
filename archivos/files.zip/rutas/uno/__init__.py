def init(db, api, **otros):
    print(f"Base de datos: {db} Api: {api}")

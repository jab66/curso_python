edad = input("Edad: ")
edad = int(edad)

if edad > 55:
    print("Puedes ver la pelicula con descuento")
elif edad > 17:
    print("Puedes ver la pelicula")
else:
    print("No puedes ver la pelicula")

print("Listo")

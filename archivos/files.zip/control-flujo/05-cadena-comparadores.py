edad = 35

# if edad >= 15 and edad <= 65:
#     print("puede ingresar a la piscina")

if 15 <= edad <= 65:
    print("puede ingresar a la piscina")

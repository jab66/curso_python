buscar = 31

for numero in range(5):
    print(numero)
    if numero == buscar:
        print("encontrado ", buscar)
        break
else:
    print("no encontrado", buscar)

for char in "Jorge":
    print(char)

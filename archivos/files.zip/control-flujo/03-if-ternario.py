edad = 19

# if edad > 17:
#     mensaje = "es mayor"
# else:
#     mensaje = "es menor"

mensaje = "es mayor" if edad > 17 else "es menor"

print(mensaje)

class Perro:
    def ladra(self):
        print("Guau!!!")


mi_perro = Perro()
mi_perro.ladra()

print(isinstance(mi_perro, Perro))

# las tuplas no se pueden modificar
# se pueden usar todos los metodos de una lista, a exepxion de aquellas que la pueden modiificar.

numeros = (1, 2, 3)
print(numeros)

numeros2 = (1, 2, 3)+(4, 5, 6)
print(numeros2)

# lista a tupla
punto = tuple([1, 2, 3])
print(punto)

numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["Hola", "mundo"]
booleans = [True, True, False]
matriz = [[0, 1], [1, 2]]
ceros = [0] * 10
# juntar 2 listas en una lista
alfanumericos = numeros + letras
# generar una lista con 10 elementos
rango = list(range(1, 11))
# generar una lista con una cadena de string
chars = list("hola mundo")
print(chars)

try:
    numero = int(input("Ingresa un número: "))
except:
    print("Ocurrio un error")

def mensaje(nombre, apellido="feliz"):
    print(f"Bienvenido {nombre} {apellido}")


mensaje("Jorge", "Bianculli")
mensaje("Jorge")

mensaje(apellido="Bianculli", nombre="Alejandro")

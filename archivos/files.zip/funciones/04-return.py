def suma(a, b):
    resultado = a + b
    return resultado


valor = suma(5, 2)
print(valor)

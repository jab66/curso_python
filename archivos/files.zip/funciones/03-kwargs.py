def get_product(**datos):
    print(datos)
    print(datos["lastname"])


get_product(id=2, name="Jorge", lastname="Bianculli")

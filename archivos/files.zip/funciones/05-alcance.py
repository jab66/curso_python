saludo = "Primer saludo"


def saludar():
    saludo = "Hola Mundo"
    print(saludo)


def saludar2():
    saludo = "Bienvenido"
    print(saludo)


saludar()
saludar2()

# no cambia su valor
print(saludo)

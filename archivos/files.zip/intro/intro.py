""" Module providing a function printing. """

print("Intro Python!")

print("Hola " * 4)

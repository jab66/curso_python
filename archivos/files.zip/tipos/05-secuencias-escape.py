curso = "Ultimate Python"
print(curso)

curso = 'Ultimate "Python"'
print(curso)

curso = "Ultimate \"Python\""
print(curso)

curso = "Ultimate \\Python\\"
print(curso)

curso = "Ultimate \nPython"
print(curso)


# int()
# str()
# float()
# bool()   -->> "" 0 None

print(bool(""))
print(bool("0"))
print(bool(None))
print(bool(" "))
print(bool(0))

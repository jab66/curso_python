curso_python = "Ultimate Python"
descripcion_curso = """
Este curso contempla todos los temas para aprender python."""

print(curso_python, descripcion_curso)

print(len(curso_python))

print(curso_python[0])

print(curso_python[0:8])

print(curso_python[9:])

print(curso_python[:8])

print(curso_python[:])

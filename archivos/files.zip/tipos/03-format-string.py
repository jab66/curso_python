# caso 1
nombre = "Jorge"
apellido = "Bianculli"
nombre_completo = nombre+" "+apellido

print(nombre_completo)

# caso 2
nombre = "Jorge"
apellido = "Bianculli"
nombre_completo = f"{nombre} {apellido}"
nombre_completo2 = f"{nombre[0]} {2 + 3}"

print(nombre_completo)
print(nombre_completo2)

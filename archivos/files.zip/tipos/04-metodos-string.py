nombre = "Jorge alejandro"

print(nombre.upper())
print(nombre.lower())
print(nombre.capitalize())
print(nombre.title())
print(nombre.find("ge"))
print(nombre.find("Ge"))
print(nombre.replace("ge", "XX"))
print("ge" in nombre)
print("ge" not in nombre)

# limpia los blancos de los extremos de la variable
# print(nombre.strip())  # lstrip() rstrip()
# print(nombre.strip().capitalize())

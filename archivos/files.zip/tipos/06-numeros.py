numero = 2
print(numero)

print(1 + 1)
print(5 - 2)
print(2 * 2)
print(6 / 2)
print(8 // 3)  # el entero
print(8 % 3)  # el resto de la division
print(2 ** 3)  # elevado a

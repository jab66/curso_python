nombre_curso = "Curso Python"
nombre_alumno = "Jorge"
alumnos = 5
puntaje = 9.9
publicado = True


print(nombre_curso, nombre_alumno, alumnos, puntaje, publicado)

def guardar():
    print("guardando")


def pagar_impuestos():
    print("pagando impuestos")

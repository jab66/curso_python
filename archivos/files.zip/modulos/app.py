from usuario_impuestos import guardar, pagar_impuestos

guardar()
pagar_impuestos()
